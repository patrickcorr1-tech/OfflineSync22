import "./App.css";
import heroImage from "./assets/hero-latest.jpg";
import { motion, type Variants, AnimatePresence } from "framer-motion";
import { useEffect, useRef, useState } from "react";
import ThemeToggle from "./ThemeToggle";
// Background shader removed for performance - using CSS gradient instead

const fadeUp: Variants = {
  hidden: { opacity: 0, y: 12 },
  show: {
    opacity: 1,
    y: 0,
    transition: { duration: 0.4, ease: "easeOut" },
  },
};

const stagger: Variants = {
  show: { transition: { staggerChildren: 0.08 } },
};

// Project Modal Component
function ProjectModal({ project, isOpen, onClose }: { 
  project: any; 
  isOpen: boolean; 
  onClose: () => void;
}) {
  useEffect(() => {
    if (isOpen) {
      document.body.style.overflow = 'hidden';
    } else {
      document.body.style.overflow = '';
    }
    return () => {
      document.body.style.overflow = '';
    };
  }, [isOpen]);

  if (!isOpen || !project) return null;

  return (
    <AnimatePresence>
      {isOpen && (
        <motion.div
          className="modal-overlay"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          onClick={onClose}
        >
          <motion.div
            className="modal-content"
            initial={{ scale: 0.9, y: 20 }}
            animate={{ scale: 1, y: 0 }}
            exit={{ scale: 0.9, y: 20 }}
            onClick={(e) => e.stopPropagation()}
          >
            <button className="modal-close" onClick={onClose} aria-label="Close">
              ×
            </button>
            <div className="modal-header">
              <span className="modal-tag">{project.category}</span>
              <h3>{project.title}</h3>
            </div>
            <div className="modal-body">
              {project.detailsTitle && (
                <p className="modal-project-title">
                  <strong>{project.detailsTitle}</strong>
                </p>
              )}
              <p>{project.details}</p>
              
              {project.tech && (
                <div className="modal-tech">
                  <h4>Technology</h4>
                  <div className="tech-tags">
                    {project.tech.map((t: string) => (
                      <span key={t} className="tech-tag">{t}</span>
                    ))}
                  </div>
                </div>
              )}
              
              {project.outcome && (
                <div className="modal-outcome">
                  <h4>Outcome</h4>
                  <p>{project.outcome}</p>
                </div>
              )}
              
              {project.link && (
                <div className="modal-footer">
                  <a href={project.link} className="modal-link">
                    View full case study →
                  </a>
                </div>
              )}
            </div>
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>
  );
}

// Navigation Bar Component with Mobile Menu
function NavBar() {
  const [menuOpen, setMenuOpen] = useState(false);

  return (
    <div className="nav">
      <div className="nav-brand">
        <div className="logo">Patrick Corr</div>
      </div>
      
      {/* Desktop Navigation */}
      <nav className="links desktop-nav">
        <a href="#home">Home</a>
        <a href="#about">About</a>
        <a href="#projects">Projects</a>
        <a href="#contact">Contact</a>
      </nav>
      
      {/* Mobile Menu Button */}
      <button 
        className={`mobile-menu-btn ${menuOpen ? 'open' : ''}`}
        onClick={() => setMenuOpen(!menuOpen)}
        aria-label="Toggle menu"
      >
        <span></span>
        <span></span>
        <span></span>
      </button>
      
      {/* Mobile Navigation */}
      <div className={`mobile-nav ${menuOpen ? 'open' : ''}`}>
        <nav className="links">
          <a href="#home" onClick={() => setMenuOpen(false)}>Home</a>
          <a href="#about" onClick={() => setMenuOpen(false)}>About</a>
          <a href="#projects" onClick={() => setMenuOpen(false)}>Projects</a>
          <a href="#contact" onClick={() => setMenuOpen(false)}>Contact</a>
        </nav>
      </div>
      
      <div className="nav-actions">
        <ThemeToggle />
      </div>
    </div>
  );
}

export default function App() {
  // Remove expensive mouse/scroll tracking that runs on every frame
  // This was causing main-thread work issues

  const carouselRef = useRef<HTMLDivElement | null>(null);
  const [filter, setFilter] = useState("All");
  const [selectedProject, setSelectedProject] = useState<any>(null);
  const [isModalOpen, setIsModalOpen] = useState(false);

  const projects = [
    {
      title: "Next Gen CCTV AI",
      summary: "Intelligent video analytics for proactive security and insights.",
      detailsTitle: "Next‑Gen CCTV & Site Intelligence, £10m Construction Fit‑Out",
      details:
        "Implemented a multi‑zone Verkada CCTV platform with automated PPE detection, tamper protection, and targeted alert routing. Leveraged analytics and monitoring workflows to enhance site safety, investigation speed, and operational insight. The system provides intelligent video analytics with automated PPE detection, ensuring site safety compliance across all work zones.",
      category: "CCTV",
      tech: ["Verkada Command", "AI Analytics", "PPE Detection", "Cloud Storage"],
      outcome: "40% faster incident response time",
      link: "/projects/cctv-ai-analytics.html",
    },
    {
      title: "Video Time Lapsing",
      summary: "Construction Time‑Lapse & Video Production",
      details:
        "Professional construction time-lapse documentation and video production for long-term projects. 4K time-lapse cameras with weatherproof housing, automated daily capture schedules, cloud-synced footage with redundant backup, professional editing and colour grading, music and graphics overlay options.",
      category: "Video",
      tech: ["4K Cameras", "Adobe Premiere", "Cloud Sync", "Weatherproof Housing"],
      outcome: "Documented £15m build progress",
    },
    {
      title: "Starlink",
      summary: "Remote Connectivity Deployment",
      details:
        "Rapid deployment of Starlink satellite internet for remote construction sites and temporary offices where traditional connectivity is unavailable. 50-200 Mbps download speeds in remote locations, quick setup (under 1 hour from box to online), load balancing with existing connections for redundancy, temporary or permanent installation options.",
      category: "Connectivity",
      tech: ["Starlink", "Network Design", "Load Balancing", "Mobile Trailers"],
      outcome: "99.9% uptime in rural location",
    },
  ];

  const filters = ["All", "CCTV", "Connectivity", "Video", "VOIP"];
  const visibleProjects = filter === "All" ? projects : projects.filter((p) => p.category === filter);

  const openModal = (project: any) => {
    setSelectedProject(project);
    setIsModalOpen(true);
  };

  const closeModal = () => {
    setIsModalOpen(false);
    setTimeout(() => setSelectedProject(null), 300);
  };

  return (
    <div className="page">
      {/* Static gradient background - no JavaScript */}
      <div className="static-bg" />
      
      {/* Project Modal */}
      <ProjectModal 
        project={selectedProject} 
        isOpen={isModalOpen} 
        onClose={closeModal} 
      />
      
      <header className="hero" id="home">
        <div className="glow" />
        <div className="container">
        <NavBar />

        <div className="hero-grid">

          <motion.div
            className="hero-copy"
            variants={stagger}
            initial="hidden"
            animate="show"
          >
            <motion.h1 variants={fadeUp}>
              Patrick Corr Head of IT &amp; Security Leader (UK &amp; Europe)
            </motion.h1>
            <motion.p className="sub" variants={fadeUp}>
              Delivering Microsoft 365 migrations, Google Workspace to 365,
              multi‑site networks, cloud VOIP, and AI CCTV with secure, scalable
              infrastructure across the UK &amp; Europe.
            </motion.p>
            <motion.div className="cta" variants={fadeUp}>
              <a className="btn primary" href="#about">
                About Me
              </a>
              <a className="btn ghost" href="#projects">
                View Projects
              </a>
            </motion.div>
            <p className="hero-intro">Focused on secure delivery, clean execution, and measurable impact for multi‑site IT.</p>
            <div className="glance-strip">
              <span>Security</span>
              <span>Connectivity</span>
              <span>Automation</span>
              <span>Multi‑site</span>
            </div>
          </motion.div>

          

          <motion.div
            className="hero-photo"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, ease: "easeOut" }}
          >
            <div className="photo-frame">
              <img src={heroImage} alt="Patrick Corr" loading="eager" decoding="async" fetchPriority="high" width="360" height="540" style={{aspectRatio: '2/3'}} />
            </div>
          </motion.div>
        </div>
        <a className="scroll-indicator" href="#about">
          <span className="scroll-dot" />
          <span>Scroll</span>
        </a>
        </div>
      </header>

      <section className="stats-section">
        <motion.div 
          className="stats-bar centered-stats" 
          variants={fadeUp}
          initial="hidden"
          whileInView="show"
          viewport={{ once: true }}
        >
          <div className="stat"><strong>5</strong><span>Businesses</span></div>
          <div className="stat"><strong>6</strong><span>Sites</span></div>
          <div className="stat"><strong>10+</strong><span>Years Exp</span></div>
        </motion.div>
      </section>

      <section className="section" id="about">
        <motion.div
          className="section-head"
          variants={stagger}
          initial="hidden"
          whileInView="show"
          viewport={{ once: true, amount: 0.3 }}
        >
          <motion.h2 variants={fadeUp}>
            Head of IT | Technology &amp; Security Leader
          </motion.h2>
          <motion.p variants={fadeUp}>UK / Europe</motion.p>
        </motion.div>

        <motion.div
          className="about-stack"
          variants={stagger}
          initial="hidden"
          whileInView="show"
          viewport={{ once: true, amount: 0.2 }}
        >
          <motion.div className="about-card" variants={fadeUp}>
            <h3>Overview</h3>
            <p>
              Currently leading IT operations across 5 distinct businesses, supporting 6 physical sites with a flexible working model. While I predominantly work remotely to provide continuous support, I maintain a regular schedule with weekly on-site presence at 2 primary locations. When critical issues demand physical intervention, I'm available to deploy to any site to resolve problems directly.

              With over a decade of experience building
              secure, scalable technology environments for multi‑site organisations.
              My work focuses on aligning IT strategy with business goals,
              strengthening cybersecurity, modernising infrastructure, and enabling
              operational resilience. I combine strategic leadership with hands‑on
              delivery to ensure technology supports growth, efficiency, and
              long‑term stability.
            </p>
          </motion.div>

          <motion.div className="about-card" variants={fadeUp}>
            <h3>What I Do</h3>
            <ul>
              
              <li>Lead cybersecurity and risk management frameworks</li>
              <li>Modernise infrastructure and cloud architecture</li>
              <li>Oversee ERP and enterprise system delivery</li>
              <li>Manage vendors, MSPs, and technology budgets</li>
              <li>Build business continuity and disaster recovery capability</li>
              <li>Support executive decision‑making with clear technical insight</li>
            </ul>
          </motion.div>

          <motion.div className="about-card" variants={fadeUp}>
            <h3>Professional Impact</h3>
            <p>
              <strong>Wentforth Group — Group IT Manager / Head of IT</strong>
              <br />
              2019 – Present
            </p>
            <ul>
              <li>Delivered group‑wide IT strategy supporting expansion and resilience</li>
              <li>Enabled enterprise IT operations for 250+ users</li>
              <li>Implemented layered cybersecurity protections</li>
              <li>Directed ERP implementation and optimisation</li>
              <li>Modernised server, network, and virtual infrastructure</li>
              <li>Managed vendors, budgets, and service performance</li>
              <li>Established continuity and disaster recovery frameworks</li>
            </ul>
          </motion.div>

          <motion.div className="about-card" variants={fadeUp}>
            <h3>Technical Environment</h3>
            <p>
              Windows Server • Active Directory • Virtualisation • Cloud &amp; Hybrid
              Infrastructure • ERP Platforms • Cybersecurity Architecture • WAN/VPN/DNS
              • Microsoft 365 • API Integrations • MDM
            </p>
          </motion.div>

          <motion.div className="about-card" variants={fadeUp}>
            <h3>Background</h3>
            <p>
              Career foundations in consultancy, education‑sector IT, and hardware
              systems built a strong operational understanding that informs my
              leadership today.
            </p>
            <p>
              <strong>BSc (Hons) Network Management &amp; Design</strong> Sheffield Hallam
              University
            </p>
          </motion.div>
        </motion.div>
      </section>

      
      <section className="section" id="services">
        <div className="section-head">
          <h2>Services</h2>
          <p>
            Microsoft 365 migrations, Google Workspace to 365, multi‑site network
            design, cloud VOIP, AI CCTV, and secure infrastructure delivery across
            the UK &amp; Europe.
          </p>
        </div>
        <div className="services-grid">
          <div className="service-card">Microsoft 365 Migration &amp; Identity</div>
          <div className="service-card">Google Workspace to 365</div>
          <div className="service-card">Multi‑site Networks &amp; WAN/VPN</div>
          <div className="service-card">Cloud VOIP &amp; Telephony</div>
          <div className="service-card">AI CCTV &amp; Security Systems</div>
          <div className="service-card">Infrastructure Hardening</div>
        </div>
      </section>

      <section className="section" id="projects">
        <div className="section-head">
          <h2>Projects</h2>
        </div>
        <div className="filter-bar">
          {filters.map((item) => (
            <button
              key={item}
              className={filter === item ? "active" : ""}
              onClick={() => setFilter(item)}
            >
              {item}
            </button>
          ))}
        </div>
        <div className="project-spotlight">
          {visibleProjects.map((project) => (
            <div key={project.title} className="spotlight-card">
              <p className="mini-title">New</p>
              <h3>{project.title}</h3>
              <p>{project.summary}</p>
              <button 
                className="read-more-btn"
                onClick={() => openModal(project)}
              >
                ▶ Read more
              </button>
            </div>
          ))}
        </div>

        <div className="carousel-wrap">
          <div className="carousel-head">
            <h3>Featured Projects</h3>
            <div className="carousel-controls">
              <button onClick={() => carouselRef.current?.scrollBy({ left: -320, behavior: "smooth" })}>◀</button>
              <button onClick={() => carouselRef.current?.scrollBy({ left: 320, behavior: "smooth" })}>▶</button>
            </div>
          </div>
          <div className="carousel" ref={carouselRef}>
            <div className="carousel-card">Verkada CCTV — Site Intelligence</div>
            <div className="carousel-card">Starlink — Remote Connectivity</div>
            <div className="carousel-card">VOIP — Multi‑site Telephony</div>
            <div className="carousel-card">CCTV Automation — PPE Compliance</div>
            <div className="carousel-card">Construction Time‑Lapse</div>
          </div>
        </div>
      </section>

      <section className="section" id="blog">
        <div className="section-head">
          <h2>From the Blog</h2>
          <p>Practical IT insights for business leaders.</p>
        </div>
        <div className="blog-grid" style={{gridTemplateColumns: '1fr', maxWidth: '600px', margin: '1.5rem auto 0'}}>
          <a href="/blog/cybersecurity-mistakes-business.html" className="blog-card" style={{minHeight: '180px'}}>
            <span className="blog-tag">Security</span>
            <h3>5 Cybersecurity Mistakes That Could Shut Down Your Business</h3>
            <p>Real mistakes I've seen cost businesses thousands. Learn what to avoid and how to protect your company.</p>
            <span className="read-link">Read article →</span>
          </a>
        </div>
        <div style={{ textAlign: 'center', marginTop: '2rem' }}>
          <a href="/blogs.html" className="btn ghost">View all articles</a>
        </div>
      </section>

      <section className="section" id="testimonials">
        <div className="section-head">
          <h2>Endorsements</h2>
          <p>Trusted by teams who need reliable, secure delivery.</p>
        </div>
        <div className="testimonial-strip">
          <div className="testimonial">
            "Patrick delivers secure, scalable solutions with a calm, pragmatic approach, exactly what you want in high‑pressure environments."
          </div>          <div className="testimonial">
            "Dependable, detail‑focused, and outcomes‑driven. A safe pair of hands
            for critical infrastructure."
          </div>
        </div>
      </section>

      <section className="section" id="contact">
        <motion.div
          className="contact-wrap"
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, amount: 0.3 }}
          transition={{ duration: 0.6 }}
        >
          <div>
            <h2>Contact</h2>
            <p>
              Ready to build something exceptional? Let's talk about your next
              project.
            </p>
          </div>
          <div className="contact-links">
            <a className="btn primary" href="mailto:patrickcorr4@gmail.com">
              Contact Me
            </a>
            <a className="email-link" href="mailto:patrickcorr4@gmail.com">
              patrickcorr4@gmail.com
            </a>
            <a
              className="email-link"
              href="https://www.linkedin.com/in/patrick-corr-bb2762121"
              target="_blank"
              rel="noreferrer"
            >
              LinkedIn Profile
            </a>
          </div>
        </motion.div>
      </section>

      <footer className="footer">
        © {new Date().getFullYear()} Patrick Corr · Last updated Feb 2026 · <a href="#home">Back to top</a>
      </footer>
    </div>
  );
}
