import { useEffect, useRef } from "react";
import * as THREE from "three";
import { GLTFLoader } from "three/examples/jsm/loaders/GLTFLoader.js";
import { PointerLockControls } from "three/examples/jsm/controls/PointerLockControls.js";

export default function WorldDemo() {
  const mountRef = useRef<HTMLDivElement | null>(null);

  useEffect(() => {
    if (!mountRef.current) return;

    const scene = new THREE.Scene();
    scene.background = new THREE.Color(0x0b0f1a);
    scene.fog = new THREE.Fog(0x0b0f1a, 8, 60);

    const camera = new THREE.PerspectiveCamera(
      60,
      mountRef.current.clientWidth / mountRef.current.clientHeight,
      0.1,
      200
    );
    camera.position.set(0, 2, 6);

    const renderer = new THREE.WebGLRenderer({ antialias: true, alpha: true });
    renderer.setSize(
      mountRef.current.clientWidth,
      mountRef.current.clientHeight
    );
    renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
    mountRef.current.appendChild(renderer.domElement);

    const hemi = new THREE.HemisphereLight(0x8cd3ff, 0x223344, 0.9);
    scene.add(hemi);

    const dir = new THREE.DirectionalLight(0xffffff, 1);
    dir.position.set(5, 10, 7);
    scene.add(dir);

    const groundGeo = new THREE.PlaneGeometry(80, 80, 32, 32);
    const groundMat = new THREE.MeshStandardMaterial({
      color: 0x1e7a44,
      roughness: 0.9,
    });
    const ground = new THREE.Mesh(groundGeo, groundMat);
    ground.rotation.x = -Math.PI / 2;
    ground.position.y = 0;
    scene.add(ground);

    const waterGeo = new THREE.PlaneGeometry(30, 20, 32, 32);
    const waterMat = new THREE.MeshStandardMaterial({
      color: 0x1d4ed8,
      roughness: 0.4,
      metalness: 0.1,
      transparent: true,
      opacity: 0.8,
    });
    const water = new THREE.Mesh(waterGeo, waterMat);
    water.rotation.x = -Math.PI / 2;
    water.position.set(-12, 0.02, 8);
    scene.add(water);

    const loader = new GLTFLoader();
    loader.load(
      "https://threejs.org/examples/models/gltf/RobotExpressive/RobotExpressive.glb",
      (gltf: any) => {
        const model = gltf.scene;
        model.scale.set(1.2, 1.2, 1.2);
        model.position.set(0, 0, 0);
        scene.add(model);
      }
    );

    const controls = new PointerLockControls(camera, renderer.domElement);
    scene.add(controls.object);

    const keys: Record<string, boolean> = {};
    const onKeyDown = (e: KeyboardEvent) => (keys[e.code] = true);
    const onKeyUp = (e: KeyboardEvent) => (keys[e.code] = false);

    window.addEventListener("keydown", onKeyDown);
    window.addEventListener("keyup", onKeyUp);

    const speed = 0.08;

    const animate = () => {
      requestAnimationFrame(animate);

      if (keys["KeyW"]) controls.moveForward(speed);
      if (keys["KeyS"]) controls.moveForward(-speed);
      if (keys["KeyA"]) controls.moveRight(-speed);
      if (keys["KeyD"]) controls.moveRight(speed);

      renderer.render(scene, camera);
    };
    animate();

    const onResize = () => {
      if (!mountRef.current) return;
      camera.aspect = mountRef.current.clientWidth / mountRef.current.clientHeight;
      camera.updateProjectionMatrix();
      renderer.setSize(
        mountRef.current.clientWidth,
        mountRef.current.clientHeight
      );
    };

    window.addEventListener("resize", onResize);

    return () => {
      window.removeEventListener("resize", onResize);
      window.removeEventListener("keydown", onKeyDown);
      window.removeEventListener("keyup", onKeyUp);
      renderer.dispose();
      mountRef.current?.removeChild(renderer.domElement);
    };
  }, []);

  return (
    <div className="world-wrap">
      <div className="world-overlay">
        <div>
          <strong>3D Demo</strong>
          <span>Click to lock mouse, WASD to walk</span>
        </div>
        <button
          onClick={() => {
            const canvas = mountRef.current?.querySelector("canvas");
            if (canvas) (canvas as HTMLCanvasElement).requestPointerLock();
          }}
        >
          Start
        </button>
      </div>
      <div className="world-canvas" ref={mountRef} />
    </div>
  );
}
