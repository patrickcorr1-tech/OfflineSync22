import { useEffect, useState } from "react";

type Theme = "dark" | "light" | "auto";

export default function ThemeToggle() {
  const [theme, setTheme] = useState<Theme>("auto");

  useEffect(() => {
    const saved = localStorage.getItem("theme") as Theme | null;
    const systemPrefersLight = window.matchMedia("(prefers-color-scheme: light)").matches;
    const initial: Theme = saved ?? "auto";

    const initialResolved = initial === "auto" ? (systemPrefersLight ? "light" : "dark") : initial;
    setTheme(initial);
    document.documentElement.dataset.theme = initialResolved;

    const media = window.matchMedia("(prefers-color-scheme: light)");
    const onChange = (e: MediaQueryListEvent) => {
      const stored = localStorage.getItem("theme") as Theme | null;
      if (stored && stored !== "auto") return;
      const next = e.matches ? "light" : "dark";
      document.documentElement.dataset.theme = next;
    };

    if (media.addEventListener) {
      media.addEventListener("change", onChange);
    } else {
      media.addListener(onChange);
    }

    return () => {
      if (media.removeEventListener) {
        media.removeEventListener("change", onChange);
      } else {
        media.removeListener(onChange);
      }
    };
  }, []);

  const setAndStore = (next: Theme) => {
    setTheme(next);
    if (next === "auto") {
      localStorage.removeItem("theme");
      const systemPrefersLight = window.matchMedia("(prefers-color-scheme: light)").matches;
      const nextResolved = systemPrefersLight ? "light" : "dark";
      document.documentElement.dataset.theme = nextResolved;
      return;
    }
    document.documentElement.dataset.theme = next;
    localStorage.setItem("theme", next);
  };

  return (
    <div className="theme-toggle">
      <button
        className={theme === "auto" ? "active" : ""}
        onClick={() => setAndStore("auto")}
      >
        Auto
      </button>
      <button
        className={theme === "dark" ? "active" : ""}
        onClick={() => setAndStore("dark")}
      >
        Dark
      </button>
      <button
        className={theme === "light" ? "active" : ""}
        onClick={() => setAndStore("light")}
      >
        Light
      </button>
    </div>
  );
}
