// INSTALL: npm i three @react-three/fiber @react-three/drei
// USAGE: <div style={{ height: "70vh" }}><MossGnodesEffect /></div>

import React, { useMemo, useRef } from "react";
import { Canvas, useFrame } from "@react-three/fiber";
import type { ThreeEvent } from "@react-three/fiber";
import * as THREE from "three";

export type MossGnodesEffectProps = {
  radius?: number;
  mossCount?: number;
  planeSize?: number;
  surfaceAmp?: number;
  surfaceNoiseScale?: number;
  surfaceSpeed?: number;
  mossBaseScale?: number;
  mossReactScale?: number;
  mossBend?: number;
  cursorLerp?: number;
  cameraOrbitRadius?: number;
  cameraOrbitSpeed?: number;
  cameraDriftAmp?: number;
  className?: string;
  style?: React.CSSProperties;
};

export function MossGnodesEffect({
  radius = 2.2,
  mossCount = 2200,
  planeSize = 14,
  surfaceAmp = 0.35,
  surfaceNoiseScale = 0.8,
  surfaceSpeed = 0.45,
  mossBaseScale = 0.12,
  mossReactScale = 0.55,
  mossBend = 0.25,
  cursorLerp = 0.08,
  cameraOrbitRadius = 5.5,
  cameraOrbitSpeed = 0.12,
  cameraDriftAmp = 0.35,
  className,
  style,
}: MossGnodesEffectProps) {
  return (
    <div className={className} style={{ width: "100%", height: "100%", ...style }}>
      <Canvas
        dpr={[1, 2]}
        gl={{ antialias: true, powerPreference: "high-performance" }}
        camera={{ position: [0, 3, 8], fov: 55, near: 0.1, far: 200 }}
      >
        <Scene
          radius={radius}
          mossCount={mossCount}
          planeSize={planeSize}
          surfaceAmp={surfaceAmp}
          surfaceNoiseScale={surfaceNoiseScale}
          surfaceSpeed={surfaceSpeed}
          mossBaseScale={mossBaseScale}
          mossReactScale={mossReactScale}
          mossBend={mossBend}
          cursorLerp={cursorLerp}
          cameraOrbitRadius={cameraOrbitRadius}
          cameraOrbitSpeed={cameraOrbitSpeed}
          cameraDriftAmp={cameraDriftAmp}
        />
      </Canvas>
    </div>
  );
}

function Scene({
  radius,
  mossCount,
  planeSize,
  surfaceAmp,
  surfaceNoiseScale,
  surfaceSpeed,
  mossBaseScale,
  mossReactScale,
  mossBend,
  cursorLerp,
  cameraOrbitRadius,
  cameraOrbitSpeed,
  cameraDriftAmp,
}: Required<Omit<MossGnodesEffectProps, "className" | "style">>) {
  const planeRef = useRef<THREE.Mesh>(null!);
  const mossRef = useRef<THREE.InstancedMesh>(null!);

  const cursorTarget = useRef(new THREE.Vector3(999, 0, 999));
  const cursorSmoothed = useRef(new THREE.Vector3(999, 0, 999));
  const dummy = useMemo(() => new THREE.Object3D(), []);
  const tmpVec = useMemo(() => new THREE.Vector3(), []);
  const tmpVec2 = useMemo(() => new THREE.Vector3(), []);

  // NODE GROUP 1 — DISTRIBUTE POINTS ON SURFACE
  const points = useMemo(() => {
    const arr = new Float32Array(mossCount * 3);
    for (let i = 0; i < mossCount; i++) {
      const x = (Math.random() - 0.5) * planeSize;
      const z = (Math.random() - 0.5) * planeSize;
      arr[i * 3 + 0] = x;
      arr[i * 3 + 1] = 0;
      arr[i * 3 + 2] = z;
    }
    return arr;
  }, [mossCount, planeSize]);

  const mossColor = useMemo(() => new THREE.Color(), []);
  const colors = useMemo(() => new Float32Array(mossCount * 3), [mossCount]);

  // NODE GROUP 3 — LIVING SURFACE DEFORM (GPU)
  const material = useMemo(() => {
    const uniforms = {
      uTime: { value: 0 },
      uAmp: { value: surfaceAmp },
      uNoiseScale: { value: surfaceNoiseScale },
      uRadius: { value: radius },
      uCursor: { value: new THREE.Vector3(999, 0, 999) },
      uSpeed: { value: surfaceSpeed },
    };

    return new THREE.ShaderMaterial({
      uniforms,
      vertexShader: `
        uniform float uTime;
        uniform float uAmp;
        uniform float uNoiseScale;
        uniform float uRadius;
        uniform vec3 uCursor;
        uniform float uSpeed;

        varying float vHeight;
        varying float vInfluence;

        float hash(vec2 p){
          p = fract(p*vec2(123.34, 456.21));
          p += dot(p, p+45.32);
          return fract(p.x*p.y);
        }

        float noise(vec2 p){
          vec2 i = floor(p);
          vec2 f = fract(p);
          float a = hash(i);
          float b = hash(i + vec2(1.0, 0.0));
          float c = hash(i + vec2(0.0, 1.0));
          float d = hash(i + vec2(1.0, 1.0));
          vec2 u = f*f*(3.0-2.0*f);
          return mix(a,b,u.x) + (c-a)*u.y*(1.0-u.x) + (d-b)*u.x*u.y;
        }

        float smoothstep01(float edge0, float edge1, float x){
          float t = clamp((x - edge0) / (edge1 - edge0), 0.0, 1.0);
          return t * t * (3.0 - 2.0 * t);
        }

        void main(){
          vec3 pos = position;
          float n = noise(pos.xz * uNoiseScale + uTime * 0.25 * uSpeed);
          float wave = sin((pos.x + uTime * uSpeed) * 0.6) * 0.3 + cos((pos.z - uTime * uSpeed) * 0.7) * 0.3;
          float base = (n + wave) * uAmp;

          float d = distance(pos.xz, uCursor.xz);
          float influence = 1.0 - smoothstep01(0.0, uRadius, d);
          float bloom = influence * (uAmp * 1.6);

          pos.y += base + bloom;

          vHeight = pos.y;
          vInfluence = influence;

          gl_Position = projectionMatrix * modelViewMatrix * vec4(pos, 1.0);
        }
      `,
      fragmentShader: `
        varying float vHeight;
        varying float vInfluence;

        void main(){
          vec3 base = vec3(0.05, 0.18, 0.08);
          vec3 mid = vec3(0.10, 0.35, 0.16);
          vec3 high = vec3(0.24, 0.55, 0.28);

          float h = clamp(vHeight * 1.5 + 0.5, 0.0, 1.0);
          vec3 color = mix(base, mid, h);
          color = mix(color, high, h*h);

          color += vInfluence * vec3(0.12, 0.25, 0.18);

          gl_FragColor = vec4(color, 1.0);
        }
      `,
      fog: true,
    });
  }, [surfaceAmp, surfaceNoiseScale, radius, surfaceSpeed]);

  useFrame(({ clock, camera }) => {
    const t = clock.getElapsedTime();
    material.uniforms.uTime.value = t;
    cursorSmoothed.current.lerp(cursorTarget.current, cursorLerp);
    material.uniforms.uCursor.value.copy(cursorSmoothed.current);

    // NODE GROUP 5 — CINEMATIC CAMERA LOOP
    const ang = t * cameraOrbitSpeed;
    const camX = Math.cos(ang) * cameraOrbitRadius;
    const camZ = Math.sin(ang) * cameraOrbitRadius;
    const camY = 2.2 + Math.sin(t * 0.6) * cameraDriftAmp;
    camera.position.set(camX, camY, camZ);
    camera.lookAt(0, 0.6, 0);

    // NODE GROUP 4 — INSTANCE MOSS ON POINTS (CPU INSTANCING)
    for (let i = 0; i < mossCount; i++) {
      const x = points[i * 3 + 0];
      const z = points[i * 3 + 2];

      tmpVec.set(x, 0, z);
      tmpVec2.copy(cursorSmoothed.current);
      tmpVec2.y = 0;

      const d = tmpVec.distanceTo(tmpVec2);
      const influence = 1.0 - smoothstep(0.0, radius, d);

      const wobble =
        Math.sin(t * 2 + x * 0.7 + z * 0.4) * 0.04 +
        Math.cos(t * 1.6 + x * 0.2) * 0.03;

      const scaleY = mossBaseScale + influence * mossReactScale + wobble;
      const scaleXZ = mossBaseScale * 0.6 + influence * mossReactScale * 0.25;

      dummy.position.set(x, 0.02, z);
      dummy.rotation.set(
        0,
        wobble * 2,
        Math.sin(t + x * 0.3 + z * 0.2) * mossBend
      );
      dummy.scale.set(scaleXZ, scaleY, scaleXZ);
      dummy.updateMatrix();
      mossRef.current.setMatrixAt(i, dummy.matrix);

      const bright = 0.35 + influence * 0.65;
      mossColor.setHSL(0.32, 0.55, 0.18 + bright * 0.28);
      mossColor.toArray(colors, i * 3);
    }

    mossRef.current.instanceMatrix.needsUpdate = true;
    if ((mossRef.current as any).instanceColor) {
      (mossRef.current as any).instanceColor.needsUpdate = true;
    }
  });

  // NODE GROUP 2 — PROXIMITY FIELD (THE CORE)
  const onPointerMove = (e: ThreeEvent<PointerEvent>) => {
    cursorTarget.current.copy(e.point);
  };

  const onPointerOut = () => {
    cursorTarget.current.set(999, 0, 999);
  };

  return (
    <>
      <fog attach="fog" args={[0x0b0f1a, 8, 60]} />
      <hemisphereLight intensity={0.65} color={0x8cd3ff} groundColor={0x223344} />
      <directionalLight position={[5, 10, 7]} intensity={1} />

      <mesh ref={planeRef} onPointerMove={onPointerMove} onPointerOut={onPointerOut}>
        <planeGeometry args={[planeSize, planeSize, 160, 160]} />
        <primitive object={material} attach="material" />
      </mesh>

      <instancedMesh
        ref={mossRef}
        args={[undefined, undefined, mossCount]}
        frustumCulled={false}
        instanceMatrix-usage={THREE.DynamicDrawUsage}
      >
        <coneGeometry args={[0.12, 0.6, 6, 1]} />
        <meshStandardMaterial color={0x2f7a3d} />
        <instancedBufferAttribute attach="instanceColor" args={[colors, 3]} />
      </instancedMesh>
    </>
  );
}

function smoothstep(edge0: number, edge1: number, x: number) {
  const t = Math.max(0, Math.min(1, (x - edge0) / (edge1 - edge0)));
  return t * t * (3 - 2 * t);
}
