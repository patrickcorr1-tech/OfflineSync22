import { useEffect, useRef } from "react";
import * as THREE from "three";

export default function BackgroundShader() {
  const mountRef = useRef<HTMLDivElement | null>(null);

  useEffect(() => {
    if (!mountRef.current) return;

    const scene = new THREE.Scene();
    const camera = new THREE.OrthographicCamera(-1, 1, 1, -1, 0, 1);
    const renderer = new THREE.WebGLRenderer({ antialias: true, alpha: true });
    renderer.setSize(window.innerWidth, window.innerHeight);
    renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
    mountRef.current.appendChild(renderer.domElement);

    const uniforms = {
      uTime: { value: 0 },
      uResolution: { value: new THREE.Vector2(window.innerWidth, window.innerHeight) },
    };

    const material = new THREE.ShaderMaterial({
      uniforms,
      transparent: true,
      vertexShader: `
        void main(){
          gl_Position = vec4(position, 1.0);
        }
      `,
      fragmentShader: `
        uniform float uTime;
        uniform vec2 uResolution;

        float hash(vec2 p){
          p = fract(p*vec2(123.34, 456.21));
          p += dot(p, p+45.32);
          return fract(p.x*p.y);
        }

        float noise(vec2 p){
          vec2 i = floor(p);
          vec2 f = fract(p);
          float a = hash(i);
          float b = hash(i + vec2(1.0, 0.0));
          float c = hash(i + vec2(0.0, 1.0));
          float d = hash(i + vec2(1.0, 1.0));
          vec2 u = f*f*(3.0-2.0*f);
          return mix(a,b,u.x) + (c-a)*u.y*(1.0-u.x) + (d-b)*u.x*u.y;
        }

        void main(){
          vec2 uv = gl_FragCoord.xy / uResolution.xy;
          vec2 p = uv * 2.0 - 1.0;
          p.x *= uResolution.x / uResolution.y;

          float t = uTime * 0.007;
          float n1 = noise(p*0.9 + t);
          float n2 = noise(p*1.8 - t*0.4);
          float n3 = noise(p*3.2 + t*0.7) * 0.22;
          float depth = n1 * 0.55 + n2 * 0.25 + n3;

          // gentle parallax warp
          vec2 warp = p + vec2(n2 - 0.5, n1 - 0.5) * 0.05;
          float swirl = noise(warp * 1.4 + t*0.5);

          vec3 base = vec3(0.003, 0.006, 0.012);
          vec3 mid = vec3(0.008, 0.016, 0.028);
          vec3 high = vec3(0.018, 0.034, 0.048);

          vec3 col = mix(base, mid, depth);
          col = mix(col, high, swirl*0.22);

          float vignette = smoothstep(1.45, 0.6, length(p));
          col *= vignette;

          gl_FragColor = vec4(col, 0.18);
        }
      `,
    });

    const geometry = new THREE.PlaneGeometry(2, 2);
    const mesh = new THREE.Mesh(geometry, material);
    scene.add(mesh);

    const onResize = () => {
      renderer.setSize(window.innerWidth, window.innerHeight);
      uniforms.uResolution.value.set(window.innerWidth, window.innerHeight);
    };

    window.addEventListener("resize", onResize);

    let raf = 0;
    const animate = () => {
      uniforms.uTime.value += 1;
      renderer.render(scene, camera);
      raf = requestAnimationFrame(animate);
    };
    animate();

    return () => {
      cancelAnimationFrame(raf);
      window.removeEventListener("resize", onResize);
      renderer.dispose();
      geometry.dispose();
      material.dispose();
      mountRef.current?.removeChild(renderer.domElement);
    };
  }, []);

  return <div className="bg-canvas" ref={mountRef} />;
}
